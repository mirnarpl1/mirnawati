<?php
//koneksi database
include 'koneksi.php';

//menangkap data yang di kirim dari form

$Id_obat=$_POST['Id_obat'];
$Kode_obat=$_POST['Kode_obat'];
$Nama_obat=$_POST['Nama_obat'];
$Expired_date=$_POST['Expired_date'];
$Jumlah=$_POST['Jumlah'];
$Harga=$_POST['Harga'];


//update data ke database
mysqli_query($koneksi, "update tbl_obat set Id_obat='$Id_obat', Kode_obat='$Kode_obat', Nama_obat='$Nama_obat', Expired_date='$Expired_date', Jumlah='$Jumlah', Harga='$Harga' where Id_obat='$Id_obat'");

//mengalihkan halaman kembali ke index.php
header("location:index.php");
?>