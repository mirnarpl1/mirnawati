<?php
include('koneksi.php');
?>
   <!DOCTYPE html>
<html>
<head>
	<title>Aplikasi Apotik</title>
</head>
<body>
	<h3><a href="logout.php">Logout</a></h3>
<h2>Daftar Obat</h2>
<table border="1">
	<tr>
		<th>No.</th>
		<th>Id Obat</th>
		<th>Kode Obat</th>
		<th>Nama Obat</th>
		<th>Kadaluarsa</th>
		<th>Jumlah</th>
		<th>Harga</th>
		<th>Aksi</th>
	</tr>
	<?php
	$no=1;
	$show=mysqli_query($koneksi,"select * from tbl_obat");
	while($tampil=mysqli_fetch_assoc($show)) : ?>
		<tr>
			<td><?= $no;?></td>
			<td><?= $tampil["Id_obat"];?></td>
			<td><?= $tampil["Kode_obat"];?></td>
			<td><?= $tampil["Nama_obat"];?></td>
			<td><?= $tampil["Expired_date"];?></td>
			<td><?= $tampil["Jumlah"];?></td>
			<td><?= $tampil["Harga"];?></td>

			<td><a href="ubah.php?Id_obat=<?php echo $tampil["Id_obat"]; ?>">Edit</a> |
			<a href="delete.php?Id_obat=<?php echo $tampil["Id_obat"];?>"onclick="return confirm('yakin?')">Delete</a></td>

	    </tr>
	    <?php $no++;?>
	<?php endwhile;?>
</table>
<h2>Input Data</h2>
<form method="POST" action="">
	<label>Id Obat</label>
	<input type="number" name="Id_obat"><br>
	<label>Kode Obat</label>
	<input type="text" name="Kode_obat"><br>
	<label>Nama Obat</label>
	<input type="text" name="Nama_obat"><br>
	<label>Kadaluarsa</label>
	<input type="date" name="Expired_date"><br>
	<label>Jumlah</label>
	<input type="number" name="Jumlah"><br>
	<label>Harga</label>
	<input type="number" name="Harga"><br>
	<Button type="submit" name="simpan">Simpan</Button>
	<Button type="reset" name="batal">Batal</Button>

 <?php
 If(Isset($_POST['simpan'])){
 	$Id_obat=$_POST['Id_obat'];
 	$Kode_obat=$_POST['Kode_obat'];
 	$Nama_obat=$_POST['Nama_obat'];
 	$Expired_date=$_POST['Expired_date'];
 	$Jumlah=$_POST['Jumlah'];
 	$Harga=$_POST['Harga'];
 	$query="insert into tbl_obat set Id_obat='$Id_obat',Kode_obat='$Kode_obat',Nama_obat='$Nama_obat', Expired_date='$Expired_date', Jumlah='$Jumlah', Harga='$Harga'";
 	mysqli_query($koneksi, $query);
 	If(mysqli_affected_rows($koneksi)>0){

 		echo"
 		<script>
 		alert('Data Berhasil Disimpan');
 		document.location.href='index.php';
 		</script>
 		";
 	} else {
 		echo"
 		<script>
 		alert('Data Gagal Disimpan');
 		document.location.href='index.php';
 		</script>
 		";
 	
 	}
 }
 ?>
 </form>
	</body>
	</html>