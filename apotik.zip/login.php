<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
</head>
<body>
    
	<h3>Form Login</h3>
	<form method="POST"action="">
	<table>
		<tr>
			<td>Username</td>
			<td><input type="email" name="username"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="simpan"></td>
			<td><input type="reset" name="reset"></td>
		</tr>
	</table>
</form>

<?php
include('koneksi.php');
if(isset($_POST['simpan'])){
    $cek=mysqli_query($koneksi, "select * from login WHERE username='".$_POST['username']."' AND password='".$_POST['password']."'");
    $hasil=mysqli_fetch_array($cek);
    $count=mysqli_num_rows($cek);
    $nama_user=$hasil['username'];
    if($count>0){
    	session_start();
    	$_SESSION['username']=$nama_user;
    	header("location:index.php");
    	
    }else{
    	echo "Gagal Login";
    }

}
;?>
</body>
</html>