<!DOCTYPE html>
<html>
<title>Latihan PHP</title>
<head></head>
	<body>
		<h3>EDIT DATA </h3>
		<?php
		include 'koneksi.php';
		$Id_obat=$_GET['Id_obat'];
		$data=mysqli_query($koneksi, "select * from tbl_obat where Id_obat='$Id_obat'");
		while($tampil=mysqli_fetch_array($data)){
			?>
			<form method="post" action="update.php">
				<table>
		<tr>
		<td>Kode</td>
		<td>
		<input type="hidden" name="Id_obat" value="<?php echo $tampil['Id_obat'];?>">
		<input type="text" name="Kode_obat" value="<?php echo $tampil['Kode_obat'];?>">
	</td>
</tr>
<tr>
	<tr>
	<td>Nama Obat</td>
	<td><input type="text" name="Nama_obat" value="<?php echo $tampil['Nama_obat'];?>"></td>
	<tr>
	<td>Kadaluarsa</td>
	<td><input type="date" name="Expired_date" value="<?php echo $tampil['Expired_date'];?>"></td>
    </tr>
    <tr>
	<td>Jumlah</td>
	<td><input type="number" name="Jumlah" value="<?php echo $tampil['Jumlah'];?>"></td>
    </tr>
    <tr>
	<td>Harga</td>
	<td><input type="number" name="Harga" value="<?php echo $tampil['Harga'];?>"></td>
    </tr>
    <tr>
	<td></td>
	<td><input type="submit" name="simpan" value="SIMPAN"></td>
    </tr>
</table>
</form>
<?php
}
?>
</body>
</html>