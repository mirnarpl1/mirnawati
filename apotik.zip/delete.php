<?php
include ("koneksi.php");
$Id_obat=$_GET['Id_obat'];
mysqli_query($koneksi,"delete from tbl_obat where Id_obat='$Id_obat'");
echo"
<script>
alert('Data Berhasil Hapus');
document.location.href='index.php';
</script>
";
;?>
